//author ::vrajang shah id:000826893

public class Test {
    public static void main(String[] args) {
        Timsorder t = Timsorder.create();
        System.out.println(t);
        System.out.printf("Total Price: $%.2f\n", t.getAmountdue());
    }
}