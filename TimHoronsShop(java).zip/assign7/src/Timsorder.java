public class Timsorder  {
    private int size;
    private String customername;//instance varibles

    //constructor

    private Timsorder(int size, String customername) {


        this.size = size;
        this.customername = customername;
    }
    //method create which ask the user choice
    public static Timsorder create(){
        //calls methodes
        Boxofnails b= Boxofnails.create();
        Rentablehardware r =Rentablehardware.rented();

        //ask user for input
        String choice;
        do {
            // Menu for user interface
            System.out.println(
                    "" +"welcome to timsshop\n\n"+


                            "1) boxofnail\n" +
                            "2) nail gun\n" +
                            "3) screwdriver\n" +
                            "4) nails \n" +
                            "5) exit \n" +

                            "Your Choice: ");

            // read in the user's choice, print it back to them
            choice = keyboard.nextLine();
            System.out.println("Option " + choice + " selected!");

            // Carry out users choice
            switch(choice) {

                case "1":
                    b.(Boxofnails.create());
                    System.out.println(b);
                    break;
                case "2":
                    n.(Nailgun.create();)
                    System.out.println(r);
                    break;
                case "3":
                    r.(Rentablehardware.rented();)
                    System.out.println(b);

                  break;

                case "4":
                    r.(Rentablehardware.rented();)
                    System.out.println(r);
                    break;
                default:
                    System.out.println("Invalid choice, choose 1,2,3,4,");
                    break;
            }
        } while (choice != "5");  // Keep accepting input until the user decides to exit

        System.out.println("Exiting!");
    }

//gives the total amount
    public static double getAmountdue() {
        Boxofnails b= Boxofnails.create();
        Rentablehardware r =Rentablehardware.rented();
        double total;

        total=b.getretailPrice()+r.getRetailprice();


        return total;
    }

    @Override
    public String toString() {
        return "Timsorder{" +
                "size=" + size +
                ", customername='" + customername + '\'' +
                '}';
    }
}
