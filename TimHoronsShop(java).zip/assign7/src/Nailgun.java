public class Nailgun extends Rentablehardware {
    public String features;//instance varible
//constructor
    public Nailgun(String name, double cost, double price, double rentalcost, boolean rented, String features) {
        super(name, cost, price, rentalcost, rented);
        this.features = features;
    }
    //create method tells details of products
    public static Nailgun create(){
        Nailgun n= new Nailgun("nailgun",98.32,199.99,19.99,false,"excellent");

        return n;
    }
    //getmethods

    public String getFeatures() {
        return features;
    }

    @Override
    public String toString() {
        return "Nailgun{" +
                "features='" + features + '\'' +
                '}';
    }

    @Override
    public double getRetailprice() {
        return 0;
    }

    @Override
    public boolean isrented() {
        return false;
    }
}
