// interface rentable
public interface Rentable {

    public static void rented() {
    }
//tells that it has been returned or rented
    public abstract void returned();
    public abstract boolean isrented();

}
