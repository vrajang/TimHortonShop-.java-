public abstract class Timsproduct implements Commodity{
    private String name;   ///all the instance variables
    private  double cost;
    private double price;
   //constructor
    public Timsproduct(String name, double cost, double price) {
        this.name = name;
        this.cost = cost;
        this.price = price;
    }
//getter methods
    public String getName() {
        return name;
    }

    public double getproductioncost() {
        return cost;
    }

    public double getretailPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Timsproduct{" +
                "name='" + name + '\'' +
                ", cost=" + cost +
                ", price=" + price +
                '}';
    }
}

