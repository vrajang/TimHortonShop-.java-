public abstract class Rentablehardware  extends Timsproduct implements Rentable {

    private double rentalcost; //instance varibles
    private boolean rented;
//constructor
    public Rentablehardware(String name, double cost, double price, double rentalcost, boolean rented) {
        super(name, cost, price);
        this.rentalcost = rentalcost;
        this.rented = rented;
    }
//get method
    public double getRentalcost() {
        return rentalcost;
    }
    //rented method creates the objects and tell its rented or noy
    public void rented(){

        Rentable r= new Rentablehardware("screwdriver",98.32,199.99,19.99,true) {
            @Override
            public double getRetailprice() {
                return rentalcost;
            }

            @Override
            public boolean isrented() {
                return false;
            }

        };
        System.out.println("your equipment is rented");



    }
    //this method tell that equipment is returned or not
    public void returned(){

        System.out.println("equpment is returned"  );


    }
    //boolean method
    public boolean isRented(){

        return true;


    }

    @Override
    public String toString() {
        return "Rentablehardware{" +
                "rentalcost=" + rentalcost +
                ", rented=" + rented +
                '}';
    }
}

