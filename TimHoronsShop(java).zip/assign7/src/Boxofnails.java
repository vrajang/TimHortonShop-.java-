public class Boxofnails extends Timsproduct{
    private double size; //instance varibles
    private int quantity;
 //private constructor
    private Boxofnails(String name, double cost, double price, double size, int quantity) {
        super(name, cost, price);
        this.size = size;
        this.quantity = quantity;
    }
    //create method to create product
    public static Boxofnails create(){
        Boxofnails b= new Boxofnails("fishing nails",2.34,5.99,1.5,50);

        return b;

    }
//getter methods
    public double getSize() {
        return size;
    }

    public int getQuantity() {
        return quantity;
    }

    @Override
    public String toString() {
        return "Boxofnails{" +
                "size=" + size +
                ", quantity=" + quantity +
                '}';
    }

    @Override
    public double getRetailprice() {
        return 0;
    }
}
