public interface Commodity {

    public abstract double getproductioncost();
    public abstract double getRetailprice();
}
